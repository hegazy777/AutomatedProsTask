gsap.from(".about", {
    opacity: 0,
    y: 50,
    duration: 1,
    delay: 0.5
  });
  
gsap.from(".navbar", {
    duration: 1,
    y: -100,
    opacity: 0,
    ease: "power2.out"
  });
  

